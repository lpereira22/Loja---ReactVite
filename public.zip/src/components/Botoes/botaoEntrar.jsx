import React from "react";
import { BotaoEntrarStyles } from './botaoEntrarStyles'

const BotaoEntrar = () =>{
    return(
        <BotaoEntrarStyles>
            <div>
                <h3>Entrar</h3>
            </div>
        </BotaoEntrarStyles>
        
    )
}

export default BotaoEntrar;