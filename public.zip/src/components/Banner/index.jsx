import React from "react";
import { Container } from "./style";
import IMG from "../../assets/banner-artlancy.png";

const Banner = () => {
    return(
        <Container>
                <img src={IMG} alt="" />  
        </Container>
        
    )

}

export default Banner;