// pages/Login.jsx
import Footer from "../components/Footer";
import BotaoEntrar from "../components/Botoes/botaoEntrar";
import BotaoCadastrar from "../components/Botoes/botaoCadastrar";
import Global from "../styles/Global";
import { LoginStyles } from "./Login";
import { Link } from "react-router-dom";

function Login() {
  return (
    <LoginStyles>
          
          <div id="telaLogin">
    
              <h3><Link to="/">Voltar</Link></h3>
              <h1>Bem Vindo!</h1>
              <p>Faça o Login para continuar</p>
              <span>Login: <input type="text" /></span> 
              <span>Senha: <input type="password" /></span>
              <BotaoEntrar/>
              <BotaoCadastrar/>
              
          </div>
          
          <Global/>
    </LoginStyles>
  );
}

export default Login;
